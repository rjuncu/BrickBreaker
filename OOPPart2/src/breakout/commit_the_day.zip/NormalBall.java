package breakout;

public class NormalBall extends Ball{

	public NormalBall(Circle location, Vector velocity) {
		super(location, velocity);
		// TODO Auto-generated constructor stub
	}

}
